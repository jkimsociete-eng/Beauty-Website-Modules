LUMIÈRE BEAUTY — KIT 14 MODULES (v4 — Dark & Light)
======================================================

FICHIERS INCLUS
───────────────
00-pack-complet.html      → Tous les modules + toggle Dark/Light + Split preview
01-barre-annonce.html     → Barre fixe livraison / code promo (une ligne, fermable)
02-hero-slideshow.html    → Hero plein écran 5 teintes + pills + progress bar
03-video-compact.html     → Vidéo format compact, rotation 2 vidéos, bouton mute
04-video-full.html        → Vidéo plein écran, badges, mute, progress bar
05-hero-panel.html        → Hero plein écran + panel teinte détaillé
06-marquee.html           → Défilé produits animé infini (pause au survol)
07-comparateur.html       → Slider avant/après interactif (images fixes, tactile)
08-quiz.html              → Quiz 2 étapes → teinte recommandée + CTA direct
09-selecteur.html         → Sélecteur pastilles + image + description dynamiques
10-guide-tailles.html     → Calculateur taille/poids → format recommandé
11-showcase.html          → Showcase produit par onglets
12-dock.html              → Dock interactif valeurs marque (effet 3D)
13-email-valeurs.html     → Bloc valeurs animé + bannière capture email
README.txt                → Ce guide

═══════════════════════════════════════════════
PERSONNALISATION — 3 ÉTAPES
═══════════════════════════════════════════════

ÉTAPE 1 — Vos teintes
─────────────────────
Dans chaque fichier, trouvez le bloc SHADES dans le JavaScript :

  const SHADES = [
    {
      name:  'Perle',               ← Nom de la teinte
      sub:   'Nacré',               ← Sous-titre (marquee)
      desc:  "Légèreté nacrée...",  ← Description
      color: '#F2E0CC',             ← Couleur hex de la pastille
      badge: null,                  ← null ou 'New' ou 'Best'
      img:   'https://...',         ← URL de votre photo produit
    },
    ...
  ]

Modifiez les 5 entrées avec vos propres teintes.
Tout le reste (quiz, sélecteur, showcase, marquee...) se met à jour automatiquement.

ÉTAPE 2 — Vos vidéos
─────────────────────
Dans les modules 03 et 04, trouvez VIDEO_SRCS :

  const VIDEO_SRCS = [
    'https://res.cloudinary.com/.../video1.mp4',
    'https://res.cloudinary.com/.../video2.mp4',
  ];

Remplacez par vos propres URLs Cloudinary (ou tout hébergeur de vidéos).

ÉTAPE 3 — Votre branding
─────────────────────────
Modifiez dans le CSS :
  --g: #C9A96E    → Couleur accent dorée (tous les éléments or)
  --gl: #e8d5b0   → Couleur accent dorée claire
  --gd: #a07840   → Couleur accent dorée foncée

Modifiez dans le HTML :
  "Lumière"       → Votre nom de marque (dans la nav, les textes)
  "BEAUTY10"      → Votre code promo (barre annonce)

═══════════════════════════════════════════════
SYSTÈME DARK & LIGHT
═══════════════════════════════════════════════

Chaque module supporte 2 thèmes via l'attribut data-theme sur <html> :

  <!-- Thème sombre (défaut) -->
  <html data-theme="dark">

  <!-- Thème clair -->
  <html data-theme="light">

Le bouton 🌙/☀️ en haut à droite permet de switcher en temps réel.
Le choix est mémorisé via localStorage — vos visiteurs retrouvent leur préférence.

Pour forcer un thème fixe (sans toggle) :
  1. Retirez le bouton <button id="theme-btn">
  2. Retirez la fonction toggleTheme()
  3. Mettez l'attribut voulu sur <html>

═══════════════════════════════════════════════
INTÉGRATION SUR VOTRE SITE
═══════════════════════════════════════════════

Méthode universelle (tous CMS) :
  Ouvrez le fichier HTML du module → Copiez tout le contenu entre <body> et </body>
  → Collez dans un bloc "HTML personnalisé" de votre éditeur de page.

WordPress / Elementor :
  Bloc "HTML personnalisé" ou widget "Code HTML"

Shopify :
  Section "Custom Liquid" ou "Embed code" dans le thème

IONOS / MySite :
  Widget "Code HTML" dans l'éditeur de section

Webflow :
  Bloc "Embed" → Custom Code

Note : Le <link> Google Fonts et le <style> doivent aussi être copiés
si votre CMS ne les inclut pas automatiquement.

═══════════════════════════════════════════════
TECHNIQUE
═══════════════════════════════════════════════

Dépendances externes :
  Google Fonts (Cormorant Garamond + Josefin Sans) — chargé via CDN
  Aucune librairie JS — vanilla JavaScript uniquement
  Aucun framework CSS — CSS natif uniquement

Compatibilité navigateurs :
  Chrome, Firefox, Safari, Edge — versions modernes (2022+)
  iOS Safari 15+, Android Chrome 100+

Performance :
  Images Unsplash en lazy loading (sauf première image)
  Videos en preload="auto" (Cloudinary CDN)
  CSS transitions hardware-accelerated

═══════════════════════════════════════════════
LICENCE
═══════════════════════════════════════════════

Licence standard (ce kit) :
  → Utilisation pour 1 marque / 1 site
  → Personnalisation complète autorisée
  → Revente du kit brut interdite

Licence agence (contactez-nous) :
  → Utilisation pour plusieurs clients
  → Revente en tant que service autorisée

© Kit Lumière Beauty — Tous droits réservés
